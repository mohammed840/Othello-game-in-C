- To make the solution, run command
  $ make

- To clean the solution, run command
  $ make clean

- Game results will be stored in result.txt, if the game overs normally